# Kasun Weerasinghe — Professional Portfolio

A self-contained portfolio website for recruiters. All styling, JavaScript and photos are included in index.html. No installation or build step is required.

## Preview on your computer
Open index.html in your web browser.

## Publish using GitHub Pages
1. Sign in to GitHub and create a public repository, for example `portfolio`.
2. Unzip this package. Upload `index.html`, `.nojekyll` and this README to the repository root. Upload the files themselves, not the ZIP or enclosing folder. If your computer hides `.nojekyll`, index.html alone still works for this static website.
3. Commit the uploaded files to the `main` branch.
4. Open the repository's Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch. Select main and /(root), then Save.
6. Wait for deployment, then use Visit site in Settings > Pages. Copy that website address to your CV, LinkedIn or applications. Publishing can take up to 10 minutes.

The live site URL is different from your GitHub repository URL. Share the Pages website URL with recruiters.

## Updating your website
Edit index.html, then upload the updated file to the same repository and commit it. GitHub Pages will redeploy the changes.

## Included
- Professional profile and career history
- ERP support and operations examples
- Software projects
- Selected retail display photos
- Skills, education and professional development
- Printable recruiter summary
- Email, telephone and LinkedIn links

Contact information is displayed publicly when you publish the site. The website has no server or contact form; contact links open the visitor's email or telephone app.

GitHub documentation:
https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
